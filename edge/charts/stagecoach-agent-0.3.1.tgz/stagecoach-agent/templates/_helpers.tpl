{{- define "agent.name" -}}stagecoach-agent{{- end -}}
{{- define "agent.labels" -}}
app.kubernetes.io/name: stagecoach-agent
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end -}}
{{- define "agent.secret" -}}{{ .Values.existingSecret | default (printf "%s-token" .Release.Name) }}{{- end -}}
{{- define "agent.image" -}}
{{- if .Values.image.digest -}}
{{ .Values.image.repository }}@{{ .Values.image.digest }}
{{- else -}}
{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}
{{- end -}}
{{- define "agent.serverImage" -}}
{{- if .Values.deploys.image.digest -}}
{{ .Values.deploys.image.repository }}@{{ .Values.deploys.image.digest }}
{{- else -}}
{{- if not .Values.deploys.image.tag }}{{ fail "deploys.image.tag: set the Stagecoach server build (a commit sha) or deploys.image.digest" }}{{ end -}}
{{ .Values.deploys.image.repository }}:{{ .Values.deploys.image.tag }}
{{- end -}}
{{- end -}}
{{- define "agent.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities: {drop: [ALL]}
{{- end -}}
