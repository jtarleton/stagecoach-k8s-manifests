{{- define "sc.labels" -}}
app.kubernetes.io/name: stagecoach
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end -}}
{{- define "sc.selector" -}}
app.kubernetes.io/name: stagecoach
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "sc.image" -}}
{{- if .Values.image.digest -}}
{{ .Values.image.repository }}@{{ .Values.image.digest }}
{{- else -}}
{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}
{{- end -}}
{{- define "sc.tokenSecret" -}}{{ .Values.stagecoach.existingSecret | default (printf "%s-token" .Release.Name) }}{{- end -}}
{{- define "sc.apiSecret" -}}{{ .Values.api.existingSecret | default (printf "%s-api" .Release.Name) }}{{- end -}}
{{- define "sc.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities: {drop: [ALL]}
{{- end -}}
{{/* Registered with stagecoach.sh: always in hosted mode, optionally in community. */}}
{{- define "sc.registers" -}}
{{- if or (eq .Values.mode "hosted") .Values.stagecoach.token .Values.stagecoach.existingSecret -}}true{{- end -}}
{{- end -}}
{{/* The claim name of a pvc:// store, or "". */}}
{{- define "sc.claim" -}}
{{- if hasPrefix "pvc://" .Values.snapshots.store -}}
{{- trimPrefix "pvc://" .Values.snapshots.store | splitList "/" | first -}}
{{- end -}}
{{- end -}}
{{/* Fails on values that cannot work; included by every template that matters. */}}
{{- define "sc.validate" -}}
{{- if not (has .Values.mode (list "hosted" "community")) }}
{{- fail (printf "mode: %q is neither hosted nor community" .Values.mode) }}
{{- end }}
{{- if not .Values.environments }}
{{- fail "environments: list the environments the module operates (name, namespace, host, rank, production)" }}
{{- end }}
{{- if not (or (hasPrefix "pvc://" .Values.snapshots.store) (hasPrefix "s3://" .Values.snapshots.store)) }}
{{- fail "snapshots.store: set pvc://CLAIM (a claim in each environment's namespace, created by this chart) or s3://bucket/prefix" }}
{{- end }}
{{- if and (hasPrefix "pvc://" .Values.snapshots.store) (not .Values.jobs.likeWorkload) }}
{{- fail "snapshots.store: a pvc:// store needs jobs.likeWorkload (its Jobs take the site's DB_* env)" }}
{{- end }}
{{- if include "sc.registers" . }}
{{- if not .Values.stagecoach.clusterName }}
{{- fail "stagecoach.clusterName: name this cluster (unique within your stagecoach.sh organization)" }}
{{- end }}
{{- if not (or .Values.stagecoach.existingSecret (hasPrefix "stg_live_" .Values.stagecoach.token)) }}
{{- fail "stagecoach.token: set a cluster token (stg_live_...) from the stagecoach.sh portal, or stagecoach.existingSecret" }}
{{- end }}
{{- end }}
{{- end -}}
